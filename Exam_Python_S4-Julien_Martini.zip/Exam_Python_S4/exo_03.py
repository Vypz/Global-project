import json


def isJson():

    with open('books.json') as json_data:
        try:
            data_dict = json.load(json_data)
            data_str = json.dumps(data_dict)
            data_dict_02 = json.loads(data_str)
            json_data.close()
            return data_dict_02
        except ValueError as e:
            print(e)
            exit(1)


dataBooks = isJson()

bookCategorieJava = []
bookCategorieBusiness = []
bookCategorieClientServer = []
bookCategorieDotNet = []
bookCategorieSoftEngi = []
bookCategorieInternet = []
bookCategorieTheory = []
bookCategorieComputerGraph = []
bookCategorieNetworking = []
bookCategorieProgramming = []
bookCategoriePython = []
bookCategorieSOA = []
bookCategorieObjectOriented = []
bookCategorieMobileTech = []
bookCategorieAlgo = []
bookCategorieXML = []
bookCategorieWebDev = []
bookCategoriePerl = []
bookCategorieComputerGraphics = []
bookCategorieObjectTechnologyProgramming = []
bookCategorieMiscella = []
bookCategoriePowerBuilder = []
bookCategorieOpenSource = []
bookCategorieP = []
bookCategorieS = []
bookCategorieNext = []
bookCategorieMicrosoft = []

for val in dataBooks:
    print("Catégorie = ", val['categories'])
    for index in val['categories']:
        print("l'index est ", index)

        if index == "Java":
            #print("JAVA : TITRE DU LIVRE", val['title'])
            bookCategorieJava.append(val['title'])
        if index == "Business":
            #print("Catégorie Business ! ")
            bookCategorieBusiness.append(val['title'])

        if index == "Client-Server":
            #print("Catégorie Client-Server ! ")
            bookCategorieClientServer.append(val['title'])
        if index == "Microsoft .NET":
            print("Catégorie Microsoft .NET ! ")
            bookCategorieDotNet.append(val['title'])

        if index == "Software Engineering":
            print("Catégorie Software Engineering ! ")
            bookCategorieSoftEngi.append(val['title'])

        if index == "Internet":
            print("Catégorie Internet ! ")
            bookCategorieInternet.append(val['title'])

        if index == "Theory":
            print("Catégorie Theory ! ")
            bookCategorieTheory.append(val['title'])
        if index == "Computer Graph":
            print("Catégorie Computer Graph ! ")
        if index == "Networking":
            print("Catégorie Networking ! ")
        if index == "Programming":
            print("Catégorie Programming ! ")
        if index == "Python":
            print("Catégorie Python ! ")
        if index == "SOA":
            print("Catégorie SOA ! ")
        if index == "Object-Oriented Programming":
            print("Catégorie Object-Oriented Programming ! ")
        if index == "Mobile Technology":
            print("Catégorie Mobile Technology ! ")
        if index == "Algorithmic Art":
            print("Catégorie Algorithmic Art ! ")
        if index == "XML":
            print("Catégorie XML ! ")
        if index == "Web Development":
            print("Catégorie Web Development ! ")
        if index == "Perl":
            print("Catégorie Perl ! ")
        if index == "Computer Graphics":
            print("Catégorie Computer Graphics ! ")
        if index == "Object-Technology Programming":
            print("Catégorie Object-Technology Programming ! ")
        if index == "Miscella":
            print("Catégorie Miscella ! ")
        if index == "PowerBuilder":
            print("Catégorie PowerBuilder ! ")
        if index == "Open Source":
            print("Catégorie Open Source ! ")
        if index == "P":
            print("Catégorie P ! ")
        if index == "S":
            print("Catégorie S ! ")
        if index == "Next Generation Databases":
            print("Catégorie Next Generation Databases ! ")
        if index == "Microsoft":
            print("Catégorie Microsoft ! ")

#print("FIN JAVA", bookCategorieJava)
